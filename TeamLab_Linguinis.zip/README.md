# Team Details 

- Name: Linguinis
- Members: Francesca Carlon, Emma Raimundo Schulz

# Task Details

- Task: Emotion Classification
- Baseline model: Naive Bayes
- Evaluation: Macro F1-Score and Micro F1-Score

# Requirements 

- Language: Python
- Libraries: pandas, string, re, csv, collections, ast, math, sys, datetime, json

# Usage 
Content of "".zip: 
    - main.py           --> main file
    - DataLoader.py     --> preprocessing script 
    - NB.py             --> model script
    - evaluation.py     --> evaluation script
    - isear-train.csv   --> training data from the IMS server
    - isear-val.csv     --> validation data from the IMS server
    - isear-test.csv    --> testing data from the IMS server

- Keep all the files in the same folder
- Run main.py 
- main.py will print the Macro F1-Score, the Micro F1-Score, the date and time. 
- A .txt file with the results will be saved on the same folder. 

Results:  {'macro F1 score': 0.5219013203726642, 'micro F1 score': 0.5187772925764191}
Date:  2024-05-20
Time:  16:52:35
File created:  results_2024-05-20_16-52-35.txt

# Troubleshooting: 

- FileNotFoundError: Verify that all files are in the same directory as main.py file.

- ModuleNotFoundError: Install necessary libraries. 

# Code details: 

This code performs emotion classification. Given text data from a CSV file, it performs tokenization, applies a Naive Bayes classifier to classify text data into emotions, and evaluates its performance. The main.py file calls functions of the classes DataLoader, Evaluation and NaiveBayes, each responsible for a specific part of the text classification workflow.

- DataLoader: This class takes care of the preprocessing and tokenizing phase. It comprises the following methods:  
    - clean_files(): file cleaning, adds IDs
    - stopwords(): remove stopwords from a list of tokens
    - tokenizer(): tokenizes (punctuation signs, spaces, etc.) and gets rid of stopwords 
    - extract_types(): outputs the vocabulary of the train data

- NaiveBayes: this class comprises the functions that build the Naive Bayes classifier (with smoothing). It defines prior probability for each class, and it multiplies it with token in class + 1 over the total number of tokens for each class + total types for each tokens in each class. 
Finally, it finds the argmax and assigns each text to an emotion. 

- Evaluation: this class takes care of the evaluation phase. The methods in this class compute the Precision, Recall and F1-Score of every class by comparing the prediction with the gold standard. When running main.py, a txt file with the Macro and Micro F1-Score values is saved locally.  






